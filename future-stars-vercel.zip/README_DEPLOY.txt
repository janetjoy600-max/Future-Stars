Future Stars — Vercel Deploy
============================

Quick deploy (GitHub -> Vercel)
1) Create a new GitHub repo (e.g., future-stars).
2) Add index.html from this ZIP to the repo root and commit.
3) Go to vercel.com -> Add New -> Project -> Import your repo.
4) Framework preset: "Other". No build command needed. Output directory: / (root).
5) Deploy. Your site will be live on a vercel.app URL (connect a custom domain in Settings).

Direct deploy with Vercel CLI (optional)
1) Install Node.js and run: npm i -g vercel
2) Unzip this archive, cd into the unzipped folder (where index.html is).
3) Run: vercel --prod
4) You’ll get a production URL.

Notes
- The site is fully static and functional with local storage + QR payments preview.
- To accept live payments you’ll later plug Wave/Orange in serverless /api functions.
- Admin tab lets you set commission and preview QR codes; Tutor onboarding lets you publish tutor cards.
- Registration data saves in the visitor’s browser. For a shared admin dashboard, connect a database or Google Sheet.
